#ifndef __libc_string
#define __libc_string

extern int strcmp(char * str1, char * str2);

#endif
